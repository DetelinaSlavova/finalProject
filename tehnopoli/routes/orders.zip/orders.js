var express = require('express');
var router = express.Router();
var sha1 =require("sha1");

router.post('/', function (req, res, next) {
    res.setHeader('content-type', 'aplication/json');
    var usersCollection = req.db.get('user');
    var tmpUserId = req.session.tmpUser._id;
    var newOrder = req.body[0];
    // newOrder = JSON.parse(newOrder)
   console.log(newOrder)
      usersCollection.update({_id:tmpUserId},{ $push:
            {"orders": 5}},
            function(err, doc){
                if (err){
                    res.status(500);
                    res.json({err:err});
                } else {
                    res.status(200);
                    res.json ({message: "SUCCESSFULLY added"})
                }
            })
    //    
    })

    


module.exports = router;
